function _asyncToGenerator(fn) { return function () { var gen = fn.apply(this, arguments); return new Promise(function (resolve, reject) { function step(key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { return Promise.resolve(value).then(function (value) { step("next", value); }, function (err) { step("throw", err); }); } } return step("next"); }); }; }

module.exports = class extends think.Model {
  addV(sid, uid, vocabulary) {
    var _this = this;

    return _asyncToGenerator(function* () {
      //item and record
      try {
        let recordDB = yield _this.model('v_record').db(_this.db());
        yield _this.startTrans();
        let vid = yield _this.add(vocabulary);
        yield recordDB.add({
          sid: sid,
          vid: vid,
          uid: uid,
          rflashcard: false,
          rmatrix: false,
          rwrite: false
        });
        yield _this.commit();
      } catch (e) {
        yield _this.rollback();
        console.log(e);
      }
    })();
  }
};