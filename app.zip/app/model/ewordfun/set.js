function _asyncToGenerator(fn) { return function () { var gen = fn.apply(this, arguments); return new Promise(function (resolve, reject) { function step(key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { return Promise.resolve(value).then(function (value) { step("next", value); }, function (err) { step("throw", err); }); } } return step("next"); }); }; }

module.exports = class extends think.Model {
  create(set, vocabularies, authorid) {
    var _this = this;

    return _asyncToGenerator(function* () {
      try {
        let vocabularyDB = yield _this.model('vocabulary').db(_this.db());
        let recordDB = yield _this.model('v_record').db(_this.db());
        yield _this.startTrans();
        let sid = yield _this.add(set);
        vocabularies.forEach(function (vocabulary) {
          vocabulary.sid = sid;
          vocabulary.authorid = authorid;
        });
        let vidArr = yield vocabularyDB.addMany(vocabularies);
        let records = [];
        vidArr.forEach(function (vid) {
          records.push({
            sid: sid,
            vid: vid,
            uid: authorid,
            rflashcard: false,
            rmatrix: false,
            rwrite: false
          });
        });
        yield recordDB.addMany(records);
        yield _this.commit();
      } catch (e) {
        yield _this.rollback();
        console.log(e);
      }
    })();
  }

  remove(sid) {
    var _this2 = this;

    return _asyncToGenerator(function* () {
      try {
        let vocabularyDB = yield _this2.model('vocabulary').db(_this2.db());
        let recordDB = yield _this2.model('v_record').db(_this2.db());
        yield _this2.startTrans();
        yield _this2.where({ sid: sid }).delete();
        yield vocabularyDB.where({ sid: sid }).delete();
        yield recordDB.where({ sid: sid }).delete();
        yield _this2.commit();
      } catch (e) {
        yield _this2.rollback();
      }
    })();
  }

  acquire(sid, uid) {
    var _this3 = this;

    return _asyncToGenerator(function* () {
      try {
        let vocabularyDB = yield _this3.model('vocabulary').db(_this3.db());
        let recordDB = yield _this3.model('v_record').db(_this3.db());
        yield _this3.startTrans();
        let set = yield _this3.where({ sid: sid }).select();
        let vocabularies = yield vocabularyDB.where({ sid: sid }).select();
        let records = yield recordDB.where({ sid: sid, uid: uid }).select();
        vocabularies.forEach(function (vocabulary) {
          records.forEach(function (record) {
            if (vocabulary.vid == record.vid) {
              vocabulary.rmatrix = record.rmatrix;
              vocabulary.rflashcard = record.rflashcard;
              vocabulary.rwrite = record.rwrite;
              vocabulary.rid = record.rid;
            }
          });
        });
        yield _this3.commit();
        return {
          set: set,
          vocabularies: vocabularies
        };
      } catch (e) {
        yield _this3.rollback();
        console.log(e);
      }
    })();
  }

  //updateSV include vocabularies
  updateSV(set, vocabularies) {
    var _this4 = this;

    return _asyncToGenerator(function* () {
      try {
        let vocabularyDB = yield _this4.model('vocabulary').db(_this4.db());
        vocabularyDB._pk = 'vid';
        yield _this4.startTrans();
        yield _this4.where({ sid: set.sid }).update(set);
        yield vocabularyDB.updateMany(vocabularies);
        yield _this4.commit();
      } catch (e) {
        yield _this4.rollback();
        console.log(e);
      }
    })();
  }
};