let validateSession = (() => {
  var _ref2 = _asyncToGenerator(function* (ctx) {
    let uid = yield ctx.cookie('uid');
    if (uid == undefined) {
      ctx.body = { validated: false };
      return;
    }
    let session_userInfo = yield ctx.session(uid);
    let userInfo = yield ctx.cache(uid, undefined, 'redis');

    if (userInfo == session_userInfo && session_userInfo != undefined && userInfo != undefined) {
      return true;
    } else {
      return false;
    }
  });

  return function validateSession(_x3) {
    return _ref2.apply(this, arguments);
  };
})();

function _asyncToGenerator(fn) { return function () { var gen = fn.apply(this, arguments); return new Promise(function (resolve, reject) { function step(key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { return Promise.resolve(value).then(function (value) { step("next", value); }, function (err) { step("throw", err); }); } } return step("next"); }); }; }

module.exports = options => {
  return (() => {
    var _ref = _asyncToGenerator(function* (ctx, next) {
      if (ctx.url != '/api/user/login') {
        let sessionValidated = yield validateSession(ctx); //以后再加个ip验证和登陆次数限制
        if (sessionValidated) {
          return next();
        } else {
          ctx.body = { validated: false };
          return;
        }
      } else {
        return next();
      }
    });

    return function (_x, _x2) {
      return _ref.apply(this, arguments);
    };
  })();
};