function _asyncToGenerator(fn) { return function () { var gen = fn.apply(this, arguments); return new Promise(function (resolve, reject) { function step(key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { return Promise.resolve(value).then(function (value) { step("next", value); }, function (err) { step("throw", err); }); } } return step("next"); }); }; }

const uniqid = require('uniqid');
const model = think.model('ewordfun/folder');
module.exports = class extends think.Controller {
  __before() {
    //添加权限
  }

  listAction() {
    var _this = this;

    return _asyncToGenerator(function* () {
      let data = yield model.where({ authorid: _this.ctx.get('authorid') }).select();
      _this.body = data;
    })();
  }

  addAction() {
    var _this2 = this;

    return _asyncToGenerator(function* () {
      yield model.add({
        name: _this2.ctx.post('name'),
        intro: _this2.ctx.post('intro'),
        authorid: _this2.ctx.post('authorid'),
        createtime: Date.now()
      });
    })();
  }

  updateAction() {
    var _this3 = this;

    return _asyncToGenerator(function* () {
      let folder = {
        name: _this3.ctx.post('name'),
        intro: _this3.ctx.post('intro')
      };
      yield model.where({ fid: _this3.ctx.post('fid') }).update(model.beforeUpdate(folder));
    })();
  }

  addSetAction() {
    return _asyncToGenerator(function* () {})();
  }

  listSetAction() {
    return _asyncToGenerator(function* () {})();
  }

  deleteAction() {
    var _this4 = this;

    return _asyncToGenerator(function* () {
      yield model.where({ fid: _this4.ctx.post('fid') }).delete();
    })();
  }
};