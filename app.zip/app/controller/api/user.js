function _asyncToGenerator(fn) { return function () { var gen = fn.apply(this, arguments); return new Promise(function (resolve, reject) { function step(key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { return Promise.resolve(value).then(function (value) { step("next", value); }, function (err) { step("throw", err); }); } } return step("next"); }); }; }

const uniqid = require('uniqid');
const model = think.model('ewordfun/user');
const svgCaptcha = require('svg-captcha');
module.exports = class extends think.Controller {
  __before() {}

  addAction() {
    var _this = this;

    return _asyncToGenerator(function* () {
      yield model.add({
        uid: uniqid.process(),
        name: _this.ctx.post('name'),
        password: think.md5(_this.ctx.post('password')),
        email: _this.ctx.post('email'),
        createtime: Date.now()
      });
    })();
  }

  getCaptchaAction() {
    var _this2 = this;

    return _asyncToGenerator(function* () {
      let captcha = svgCaptcha.create({
        size: 6,
        fontSize: 32,
        color: true,
        width: 200
      });
      console.log(captcha.text);
      _this2.body = captcha.data;
    })();
  }

  loginAction() {
    var _this3 = this;

    return _asyncToGenerator(function* () {
      const email = _this3.ctx.post('email');
      const password = think.md5(_this3.ctx.post('password'));
      let data = yield model.where({ email: email, password: password }).find();
      if (think.isEmpty(data)) {
        _this3.body = { loginStatus: false };
      } else {
        let userInfo = {
          uid: data.uid,
          loginTime: Date.now(),
          uip: _this3.ctx.header['x-real-ip']
        };
        yield _this3.cookie('uid', userInfo.uid, { maxAge: 15 * 3600 * 1000 * 20 });
        yield _this3.cache(userInfo.uid, JSON.stringify(userInfo), 'redis');
        yield _this3.session(userInfo.uid, JSON.stringify(userInfo));
        _this3.body = { loginStatus: true };
      }
    })();
  }

  validateAction() {
    var _this4 = this;

    return _asyncToGenerator(function* () {
      let uid = _this4.ctx.cookie('uid');
      let userInfo = yield _this4.cache(uid, undefined, 'redis');
      let session_userInfo = yield _this4.session(uid);
      if (userInfo == session_userInfo) {
        let parsedUserInfo = JSON.parse(userInfo);
        parsedUserInfo.loginTime = Date.now();
        //更新session和redis里面的userInfo
        yield _this4.cache(uid, JSON.stringify(parsedUserInfo), 'redis');
        yield _this4.session(uid, JSON.stringify(parsedUserInfo));
        _this4.body = { validated: true };
      } else {
        _this4.body = { validated: false };
      }
    })();
  }
};