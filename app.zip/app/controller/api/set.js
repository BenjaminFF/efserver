function _asyncToGenerator(fn) { return function () { var gen = fn.apply(this, arguments); return new Promise(function (resolve, reject) { function step(key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { return Promise.resolve(value).then(function (value) { step("next", value); }, function (err) { step("throw", err); }); } } return step("next"); }); }; }

const uniqid = require('uniqid');
const model = think.model('ewordfun/set');
module.exports = class extends think.Controller {
  __before() {}
  //添加权限

  //create set indicates that it's vocabulary will be created, and record will be initialized.
  createAction() {
    let authorid = this.ctx.post('authorid');
    let set = JSON.parse(this.ctx.post('set'));
    let vocabularies = JSON.parse(this.ctx.post('vocabularies'));

    set.createtime = Date.now();
    set.authorid = authorid;
    set.vcount = vocabularies.length;

    model.create(set, vocabularies, authorid);
  }
  //remove set indicates that it's vocabularies will be removed too.
  removeAction() {
    model.remove(this.ctx.post('sid'));
  }

  acquireAction() {
    var _this = this;

    return _asyncToGenerator(function* () {
      console.log(uniqid.process());
      _this.body = yield model.acquire(_this.ctx.get('sid'), _this.ctx.get('uid'));
    })();
  }

  //update set and vocabularies both
  updateSVAction() {
    let set = JSON.parse(this.ctx.post('set'));
    let vocabularies = JSON.parse(this.ctx.post('vocabularies'));
    console.log(vocabularies);
    set.vcount = vocabularies.length; //!important
    model.updateSV(set, vocabularies);
  }

  updateAction() {
    var _this2 = this;

    return _asyncToGenerator(function* () {
      let set = JSON.parse(_this2.ctx.post('set'));
      yield model.where({ sid: set.sid }).update(set);
    })();
  }

  listAction() {
    var _this3 = this;

    return _asyncToGenerator(function* () {
      let authorid = JSON.parse(_this3.ctx.get('uid'));
    })();
  }
};