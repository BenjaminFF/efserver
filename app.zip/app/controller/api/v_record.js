function _asyncToGenerator(fn) { return function () { var gen = fn.apply(this, arguments); return new Promise(function (resolve, reject) { function step(key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { return Promise.resolve(value).then(function (value) { step("next", value); }, function (err) { step("throw", err); }); } } return step("next"); }); }; }

const model = think.model('ewordfun/v_record');
module.exports = class extends think.Controller {
  __before() {
    //添加权限
  }

  updateAction() {
    var _this = this;

    return _asyncToGenerator(function* () {
      let record = JSON.parse(_this.ctx.post('v_record'));
      yield model.where({ rid: record.rid }).update(record);
    })();
  }

  updateManyAction() {
    var _this2 = this;

    return _asyncToGenerator(function* () {
      let records = JSON.parse(_this2.ctx.post('v_records'));
      model._pk = 'rid';
      yield model.updateMany(records);
    })();
  }
};