module.exports = class extends think.Controller {
  __before() {

  }
};
