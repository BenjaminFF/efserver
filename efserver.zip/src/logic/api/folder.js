module.exports = class extends think.Logic {
  addAction(){

  }

  updateAction(){

  }

  listAction(){

  }


}
